/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* global query */
'use strict';

/**
 * Write the unit tests for your transction processor functions here
 */

const AdminConnection = require('composer-admin').AdminConnection;
const BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;
const { BusinessNetworkDefinition, CertificateUtil, IdCard } = require('composer-common');
const path = require('path');

const chai = require('chai');
chai.should();
chai.use(require('chai-as-promised'));

const namespace = 'org.conciencity';

describe('#' + namespace, () => {
    // In-memory card store for testing so cards are not persisted to the file system
    const cardStore = require('composer-common').NetworkCardStoreManager.getCardStore( { type: 'composer-wallet-inmemory' } );

    // Embedded connection used for local testing
    const connectionProfile = {
        name: 'embedded',
        'x-type': 'embedded'
    };

    // Name of the business network card containing the administrative identity for the business network
    const adminCardName = 'admin';

    // Admin connection to the blockchain, used to deploy the business network
    let adminConnection;

    // This is the business network connection the tests will use.
    let businessNetworkConnection;

    // This is the factory for creating instances of types.
    let factory;

    // These are a list of receieved events.
    let events;

    let businessNetworkName;

    before(async () => {
        // Generate certificates for use with the embedded connection
        const credentials = CertificateUtil.generate({ commonName: 'admin' });

        // Identity used with the admin connection to deploy business networks
        const deployerMetadata = {
            version: 1,
            userName: 'PeerAdmin',
            roles: [ 'PeerAdmin', 'ChannelAdmin' ]
        };
        const deployerCard = new IdCard(deployerMetadata, connectionProfile);
        deployerCard.setCredentials(credentials);
        const deployerCardName = 'PeerAdmin';

        adminConnection = new AdminConnection({ cardStore: cardStore });

        await adminConnection.importCard(deployerCardName, deployerCard);
        await adminConnection.connect(deployerCardName);
    });

    /**
     *
     * @param {String} cardName The card name to use for this identity
     * @param {Object} identity The identity details
     */
    async function importCardForIdentity(cardName, identity) {
        const metadata = {
            userName: identity.userID,
            version: 1,
            enrollmentSecret: identity.userSecret,
            businessNetwork: businessNetworkName
        };
        const card = new IdCard(metadata, connectionProfile);
        await adminConnection.importCard(cardName, card);
    }

    // This is called before each test is executed.
    beforeEach(async () => {
        // Generate a business network definition from the project directory.
        let businessNetworkDefinition = await BusinessNetworkDefinition.fromDirectory(path.resolve(__dirname, '..'));
        businessNetworkName = businessNetworkDefinition.getName();
        await adminConnection.install(businessNetworkDefinition);
        const startOptions = {
            networkAdmins: [
                {
                    userName: 'admin',
                    enrollmentSecret: 'adminpw'
                }
            ]
        };
        const adminCards = await adminConnection.start(businessNetworkName, businessNetworkDefinition.getVersion(), startOptions);
        await adminConnection.importCard(adminCardName, adminCards.get('admin'));

        // Create and establish a business network connection
        businessNetworkConnection = new BusinessNetworkConnection({ cardStore: cardStore });
        events = [];
        businessNetworkConnection.on('event', event => {
            events.push(event);
        });
        await businessNetworkConnection.connect(adminCardName);

        // Obtengo factory para la red de negocios
        factory = businessNetworkConnection.getBusinessNetwork().getFactory();

        // Creo departamentos
        let participantRegistry = await businessNetworkConnection.getParticipantRegistry(namespace+'.Departamento');
        const d1 = factory.newResource(namespace, 'Departamento', 'E1D1');
        const d2 = factory.newResource(namespace, 'Departamento', 'E1D2');
        participantRegistry.addAll([d1, d2]);
        // Creo recicladores
        participantRegistry = await businessNetworkConnection.getParticipantRegistry(namespace+'.Responsable');
        const r1 = factory.newResource(namespace, 'Responsable', 'E1R1');
        const r2 = factory.newResource(namespace, 'Responsable', 'E1R2');
        participantRegistry.addAll([r1, r2]);

        // Creo contenedores de traslado
        let assetRegistry = await businessNetworkConnection.getAssetRegistry(namespace+'.Contenedor');
        const ct1 = factory.newResource(namespace, 'Contenedor', 'E1CT1');
        const ct2 = factory.newResource(namespace, 'Contenedor', 'E1CT2');
        ct1.contenidoMaximo=10;
        ct1.contenidoActual=0;
        ct1.descripcion='Traslado';
        ct2.contenidoMaximo=10;
        ct2.contenidoActual=0;
        ct2.descripcion='Traslado';
        assetRegistry.addAll([ct1, ct2]);
        // Creo contenedores de acopio
        assetRegistry = await businessNetworkConnection.getAssetRegistry(namespace+'.Contenedor');
        const ca1 = factory.newResource(namespace, 'Contenedor', 'E1CA1');
        const ca2 = factory.newResource(namespace, 'Contenedor', 'E1CA2');
        ca1.contenidoMaximo=20;
        ca1.contenidoActual=0;
        ca1.descripcion='Traslado';
        ca2.contenidoMaximo=20;
        ca2.contenidoActual=0;
        ca2.descripcion='Traslado';
        assetRegistry.addAll([ca1, ca2]);

        // Emito identidades, utiles para interactuar con la red de negocio.
        let identity = await businessNetworkConnection.issueIdentity(namespace+'.Departamento#E1D1', 'E1D1');
        await importCardForIdentity('E1D1C1', identity);
        identity = await businessNetworkConnection.issueIdentity(namespace+'.Departamento#E1D2', 'E1D2');
        await importCardForIdentity('E1D2C1', identity);
        identity = await businessNetworkConnection.issueIdentity(namespace+'.Responsable#E1R1', 'E1R1');
        await importCardForIdentity('E1R1C1', identity);
        identity = await businessNetworkConnection.issueIdentity(namespace+'.Responsable#E1R2', 'E1R2');
        await importCardForIdentity('E1R2C1', identity);
    });

    /**
     * Reconnect using a different identity.
     * @param {String} cardName The name of the card for the identity to use
     */
    async function useIdentity(cardName) {
        await businessNetworkConnection.disconnect();
        businessNetworkConnection = new BusinessNetworkConnection({ cardStore: cardStore });
        events = [];
        businessNetworkConnection.on('event', (event) => {
            events.push(event);
        });
        await businessNetworkConnection.connect(cardName);
        factory = businessNetworkConnection.getBusinessNetwork().getFactory();
    }

    it('E1D1 puede depositar desperdicio', async () => {
        const desperdicioRegistry = await businessNetworkConnection.getAssetRegistry(namespace+'.Desperdicio');
        const contenedorRegistry = await businessNetworkConnection.getAssetRegistry(namespace+'.Contenedor');
        const paqueteRegistry = await businessNetworkConnection.getAssetRegistry(namespace+'.Paquete');
        let desperdicios = null;
        let contenedor = null;
        let transaction = null;
        let paquetes = null;

        // Usando la identidad del departamento 1 del edificio 1
        await useIdentity('E1D1C1');

        // Deposito paquetes
        transaction = factory.newTransaction(namespace, 'Entrega');
        transaction.departamento = factory.newRelationship(namespace, 'Departamento', 'E1D1');
        transaction.contenedor = factory.newRelationship(namespace, 'Contenedor', 'E1CT1');
        transaction.responsable = factory.newRelationship(namespace, 'Responsable', 'E1R1');
        transaction.peso = 50;
        await businessNetworkConnection.submitTransaction(transaction);
        // await logPaquetes('deposito');
        transaction.peso = 25;
        await businessNetworkConnection.submitTransaction(transaction);
        // await logPaquetes('deposito');
        transaction.peso = 16;
        await businessNetworkConnection.submitTransaction(transaction);
        // await logPaquetes('deposito');
        transaction.peso = 8;
        await businessNetworkConnection.submitTransaction(transaction);
        // await logPaquetes('deposito');

        desperdicios = await desperdicioRegistry.getAll();
        paquetes = await paqueteRegistry.getAll();
        contenedor = await contenedorRegistry.get(paquetes[0].contenedor.getIdentifier());
        desperdicios[0].peso.should.equal(50);
        desperdicios[1].peso.should.equal(25);
        desperdicios[2].peso.should.equal(16);
        desperdicios[3].peso.should.equal(8);
        contenedor.contenidoActual.should.equal(99);

        // Usando la identidad del reciclador 1 del edificio 1
        await useIdentity('E1R1C1');

        // Traslado paquetes
        transaction = factory.newTransaction(namespace, 'Traspaso');
        transaction.origen = factory.newRelationship(namespace, 'Contenedor', 'E1CT1');
        transaction.destino = factory.newRelationship(namespace, 'Contenedor', 'E1CA1');
        transaction.responsable = factory.newRelationship(namespace, 'Responsable', 'E1R1');
        transaction.peso = 36;
        await businessNetworkConnection.submitTransaction(transaction);
        // await logPaquetes('traslado');
        transaction.peso = 17;
        await businessNetworkConnection.submitTransaction(transaction);
        // await logPaquetes('traslado');
        transaction.peso = 10;
        await businessNetworkConnection.submitTransaction(transaction);
        // await logPaquetes('traslado');

        // Transformo paquetes
        transaction = factory.newTransaction(namespace, 'Transformacion');
        transaction.tipo = 'GAS';
        transaction.contenedor = factory.newRelationship(namespace, 'Contenedor', 'E1CA1');
        transaction.peso = 30;
        await businessNetworkConnection.submitTransaction(transaction);
        // await logPaquetes('transformacion');
        transaction.peso = 18;
        await businessNetworkConnection.submitTransaction(transaction);
        // await logPaquetes('transformacion');
        transaction.peso = 10;
        await businessNetworkConnection.submitTransaction(transaction);
        // await logPaquetes('transformacion');
        paquetes = await paqueteRegistry.getAll();

        let paquetesResiduoCT = await businessNetworkConnection.query('getPackagesFromConatiner', {contenedor: 'resource:org.conciencity.Contenedor#E1CT1', tipo: 'RESIDUO'});
        let paquetesResiduoCA = await businessNetworkConnection.query('getPackagesFromConatiner', {contenedor: 'resource:org.conciencity.Contenedor#E1CA1', tipo: 'RESIDUO'});
        let paquetesGasCA = await businessNetworkConnection.query('getPackagesFromConatiner', {contenedor: 'resource:org.conciencity.Contenedor#E1CA1', tipo: 'GAS'});
        paquetesResiduoCT.sort(function(a, b){return a.ingreso - b.ingreso;});
        paquetesResiduoCA.sort(function(a, b){return a.ingreso - b.ingreso;});
        paquetesGasCA.sort(function(a, b){return a.ingreso - b.ingreso;});
        paquetesResiduoCT[0].peso.should.equal(12);
        paquetesResiduoCT[1].peso.should.equal(16);
        paquetesResiduoCT[2].peso.should.equal(8);
        paquetesResiduoCA[0].peso.should.equal(5);
        paquetesGasCA[0].peso.should.equal(30);
        paquetesGasCA[1].peso.should.equal(6);
        paquetesGasCA[2].peso.should.equal(12);
        paquetesGasCA[3].peso.should.equal(2);
        paquetesGasCA[4].peso.should.equal(3);
        paquetesGasCA[5].peso.should.equal(5);
    });

    /** Log paquetes */
    async function logPaquetes(transaction){
        let paquetesResiduoCT = await businessNetworkConnection.query('getPackagesFromConatiner', {contenedor: 'resource:org.conciencity.Contenedor#E1CT1', tipo: 'RESIDUO'});
        let paquetesResiduoCA = await businessNetworkConnection.query('getPackagesFromConatiner', {contenedor: 'resource:org.conciencity.Contenedor#E1CA1', tipo: 'RESIDUO'});
        let paquetesGasCA = await businessNetworkConnection.query('getPackagesFromConatiner', {contenedor: 'resource:org.conciencity.Contenedor#E1CA1', tipo: 'GAS'});
        console.log(transaction);
        console.log('paquetesResiduoCT', JSON.stringify(paquetesResiduoCT.sort(function(a, b){return a.ingreso - b.ingreso;}).map((paquete) => `${paquete.contenedor.getIdentifier()} | ${paquete.tipo} | ${paquete.peso}`)));
        console.log('paquetesResiduoCA', JSON.stringify(paquetesResiduoCA.sort(function(a, b){return a.ingreso - b.ingreso;}).map((paquete) => `${paquete.contenedor.getIdentifier()} | ${paquete.tipo} | ${paquete.peso}`)));
        console.log('paquetesGasCA', JSON.stringify(paquetesGasCA.sort(function(a, b){return a.ingreso - b.ingreso;}).map((paquete) => `${paquete.contenedor.getIdentifier()} | ${paquete.tipo} | ${paquete.peso}`)));
        console.log('-------------------------------');
    }
});